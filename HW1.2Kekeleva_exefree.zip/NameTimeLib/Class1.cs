﻿using System;

namespace NameTimeLib
{
	public class Person
	{
		public string Name;
	}
	public class WriteAll
	{
		public static void Writting()

		{
			string UserName = Console.ReadLine();
			Console.WriteLine("Hello {0}!", UserName);
			DateTime dt = DateTime.Now;
			Console.WriteLine(String.Format("It's {0:t}", dt));
		}

		public static void Writting2()
		{
			var p = new Person();
			p.Name = "New user";
			Console.WriteLine("Hello, {0}! Please, give me your name.", p.Name);
			string UserName = Console.ReadLine();
			Console.WriteLine("Hello {0}!", UserName);
			DateTime dt = DateTime.Now;
			Console.WriteLine(String.Format("It's {0:t}", dt));
		}

	}
}
