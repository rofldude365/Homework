﻿using System;
using NameTimeLib;

namespace NameHW2
{
		public class Person
	{
		public string Name;
	}
	class Program
	{
		public static void Main(string[] args)
		{
			var p = new Person();
			p.Name = "New user";
			Console.WriteLine("Hello, {0}! Please, give me your name.", p.Name);
			WriteAll.Writting();

		}
	}
}
