﻿using System;

namespace NameTimeLib
{
	public class WriteAll
	{
		public static void Writting()

		{
			string UserName = Console.ReadLine();
			Console.WriteLine("Hello {0}!", UserName);
			DateTime dt = DateTime.Now;
			Console.WriteLine(String.Format("It's {0:t}", dt));
		}

		public static void Writting2()
		{
			//var Name = HMName1.Form1.textBox1.Text;
			var Time = DateTime.Now;
			//MessageBox.Show($"Hello, {Name}! It's {Time}");
		}

	}
}
